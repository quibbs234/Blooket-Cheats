# Monster Brawl Cheats

## [Double Enemy XP](doubleEnemyXp.js)
Doubles enemy XP drop value
## [Half Enemy Speed](halfEnemySpeed.js)
Makes enemies move 2x slower
## [Instant Kill](instantKill.js)
Sets all enemies health to 1
## [Invincibility](invincibility.js)
Makes you invincible
## [Kill Enemies](killEnemies.js)
Kills all currennt enemies
## [Magnet](magnet.js)
Pulls all xp towards you
## [Max Current Abilities](maxCurrentAbilities.js)
Maxes out all your current abilities
## [Next Level](nextLevel.js)
Gives you another level
## [Remove Obstacles](removeObstacles.js)
Removes all rocks and obstacles
## [Reset Health](resetHealth.js)
Resets health and gives invincibility for 3 seconds